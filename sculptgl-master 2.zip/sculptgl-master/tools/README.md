# Process ibl

```
envmap.exe -s 256 -n 4096 image.hdr
```
