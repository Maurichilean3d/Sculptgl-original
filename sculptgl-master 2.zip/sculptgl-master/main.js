import SculptGL from './src/SculptGL';

window.SculptGL = SculptGL;
